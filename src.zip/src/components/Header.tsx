"use client";
import Image from "next/image";
import Link from "next/link";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { useAuth } from "@/lib/useAuth";
export default function Header() {
  const [open, setOpen] = useState(false);
  const router = useRouter();
  const { user, signOut, role, displayName } = useAuth();
  const [menuOpen, setMenuOpen] = useState(false);

  return (
    <header className="shadow-md border-b border-gray-200" style={{ backgroundColor: "#CC2F30" }}>
      <div className="max-w-6xl mx-auto flex items-center justify-between px-4 py-3">
        {/* Logo */}
        <div className="flex items-center gap-3">
          <Image
            src="/img/logos/logo.png"
            alt="Portal Modelo Logo"
            width={72}
            height={72}
            className="w-16 h-auto sm:w-20"
            priority
          />
          <h1 className="text-2xl font-bold text-white hidden sm:block">Portal Modelo</h1>
        </div>

        {/* Menu Desktop */}
        <nav className="hidden md:flex gap-4 items-center text-white font-semibold">
          <a href="/" className="flex items-center gap-2 hover:text-yellow-500 transition">
            {/* home icon */}
            <svg className="w-5 h-5" viewBox="0 0 24 24" fill="none" aria-hidden>
              <path d="M3 10.5L12 4l9 6.5V20a1 1 0 0 1-1 1h-5v-6H9v6H4a1 1 0 0 1-1-1V10.5z" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
            Início
          </a>

          <a href="/lojas" className="flex items-center gap-2 hover:text-yellow-500 transition">
            {/* shop icon */}
            <svg className="w-5 h-5" viewBox="0 0 24 24" fill="none" aria-hidden>
              <path d="M3 9.5h18v8a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1v-8z" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
              <path d="M3 9.5L5 4h14l2.0 5.5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
            Lojas
          </a>

          <a href="/classificados" className="flex items-center gap-2 hover:text-yellow-500 transition">
            {/* megaphone icon */}
            <svg className="w-5 h-5" viewBox="0 0 24 24" fill="none" aria-hidden>
              <path d="M2 12v-2a1 1 0 0 1 1-1h6l6-3v12l-6-3H3a1 1 0 0 1-1-1z" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
              <path d="M19 8c1 1.5 1 4 0 5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
            Classificados
          </a>

          <a href="/profissionais" className="flex items-center gap-2 hover:text-yellow-500 transition">
            {/* briefcase icon */}
            <svg className="w-5 h-5" viewBox="0 0 24 24" fill="none" aria-hidden>
              <rect x="3" y="7" width="18" height="12" rx="2" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
              <path d="M8 7V6a4 4 0 0 1 8 0v1" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
            Profissionais
          </a>

          <a href="/noticias" className="flex items-center gap-2 hover:text-yellow-500 transition">
            {/* news icon */}
            <svg className="w-5 h-5" viewBox="0 0 24 24" fill="none" aria-hidden>
              <path d="M4 7h16v10H4z" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
              <path d="M8 11h8" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
            Notícias
          </a>

          <a href="/anuncie" className="flex items-center gap-2 hover:text-yellow-500 transition">
            {/* plus/announce icon */}
            <svg className="w-5 h-5" viewBox="0 0 24 24" fill="none" aria-hidden>
              <path d="M12 5v14M5 12h14" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
            Anuncie
          </a>

          {/* Área de autenticação: mostra Entrar ou usuário + Sair */}
          {user ? (
            // If user is a logista, show dropdown with Dashboard/Configurações/Sair
            role === "logista" ? (
              <div className="relative ml-3">
                <button
                  onClick={() => setMenuOpen((s) => !s)}
                  className="bg-white text-[#CC2F30] px-3 py-1 rounded-md font-semibold hover:opacity-95 transition flex items-center gap-2"
                >
                  <span className="max-w-[140px] truncate">{displayName ?? user.email}</span>
                  <svg className="w-3 h-3" viewBox="0 0 20 20" fill="none" aria-hidden>
                    <path d="M6 8l4 4 4-4" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                  </svg>
                </button>

                {menuOpen && (
                  <div className="absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg text-sm text-gray-800 z-50 overflow-hidden">
                    <a href="/dashboard" className="block px-4 py-2 hover:bg-gray-100">Dashboard</a>
                    <a href="/configuracoes" className="block px-4 py-2 hover:bg-gray-100">Configurações</a>
                    <button
                      onClick={async () => {
                        try {
                          await signOut();
                          router.push("/");
                        } catch (e) {
                          console.error(e);
                        }
                      }}
                      className="w-full text-left px-4 py-2 hover:bg-gray-100"
                    >
                      Sair
                    </button>
                  </div>
                )}
              </div>
            ) : (
              <div className="ml-3 flex items-center gap-3">
                <span className="text-white font-semibold text-sm truncate max-w-[160px]">{displayName ?? user.email}</span>
                <button
                  onClick={async () => {
                    try {
                      await signOut();
                      router.push("/");
                    } catch (e) {
                      console.error("Erro ao sair:", e);
                    }
                  }}
                  className="ml-2 bg-white text-[#CC2F30] px-3 py-1 rounded-md font-semibold hover:opacity-95 transition"
                >
                  Sair
                </button>
              </div>
            )
          ) : (
            <Link
              href="/login"
              className="ml-3 bg-white text-[#CC2F30] px-4 py-2 rounded-md font-semibold hover:opacity-95 transition flex items-center gap-2"
              aria-label="Entrar"
            >
              {/* user icon */}
              <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none" aria-hidden>
                <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                <circle cx="12" cy="7" r="4" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
              Entrar
            </Link>
          )}
        </nav>

        {/* Botões/ícone Mobile */}
        <div className="flex items-center gap-2">
          <button
            className="md:hidden text-white text-2xl p-1"
            onClick={() => setOpen(!open)}
            aria-label="Abrir menu"
          >
            {open ? (
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" aria-hidden>
                <path d="M6 6L18 18" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                <path d="M6 18L18 6" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
            ) : (
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" aria-hidden>
                <path d="M3 6h18" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                <path d="M3 12h18" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                <path d="M3 18h18" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
            )}
          </button>

          {user ? (
              <div className="md:hidden flex items-center gap-2">
              <span className="text-white text-sm truncate max-w-[120px]">{displayName ?? user.email}</span>
              <button
                onClick={async () => {
                  try {
                    await signOut();
                    router.push("/");
                  } catch (e) {
                    console.error(e);
                  }
                }}
                className="text-white px-3 py-2 rounded-md border border-white/20"
              >
                Sair
              </button>
            </div>
          ) : (
            <Link href="/login" className="md:hidden text-white px-3 py-2 rounded-md border border-white/20 flex items-center gap-2" aria-label="Entrar">
              <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none" aria-hidden>
                <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                <circle cx="12" cy="7" r="4" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
              Entrar
            </Link>
          )}
        </div>
      </div>

      {/* Menu Mobile */}
      {open && (
        <nav className="md:hidden bg-white border-t border-gray-200 flex flex-col text-blue-900 px-6 py-4 gap-3 font-semibold shadow-md">
          <a href="/" className="flex items-center gap-3 hover:text-yellow-500">
            <svg className="w-5 h-5" viewBox="0 0 24 24" fill="none"><path d="M3 10.5L12 4l9 6.5V20a1 1 0 0 1-1 1h-5v-6H9v6H4a1 1 0 0 1-1-1V10.5z" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/></svg>
            Início
          </a>

          <a href="/lojas" className="flex items-center gap-3 hover:text-yellow-500">
            <svg className="w-5 h-5" viewBox="0 0 24 24" fill="none"><path d="M3 9.5h18v8a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1v-8z" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/><path d="M3 9.5L5 4h14l2.0 5.5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/></svg>
            Lojas
          </a>

          <a href="/classificados" className="flex items-center gap-3 hover:text-yellow-500">
            <svg className="w-5 h-5" viewBox="0 0 24 24" fill="none"><path d="M2 12v-2a1 1 0 0 1 1-1h6l6-3v12l-6-3H3a1 1 0 0 1-1-1z" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/></svg>
            Classificados
          </a>

          <a href="/profissionais" className="flex items-center gap-3 hover:text-yellow-500">
            <svg className="w-5 h-5" viewBox="0 0 24 24" fill="none"><rect x="3" y="7" width="18" height="12" rx="2" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/><path d="M8 7V6a4 4 0 0 1 8 0v1" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/></svg>
            Profissionais
          </a>

          <a href="/noticias" className="flex items-center gap-3 hover:text-yellow-500">
            <svg className="w-5 h-5" viewBox="0 0 24 24" fill="none"><path d="M4 7h16v10H4z" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/><path d="M8 11h8" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/></svg>
            Notícias
          </a>

          <a href="/anuncie" className="flex items-center gap-3 hover:text-yellow-500">
            <svg className="w-5 h-5" viewBox="0 0 24 24" fill="none"><path d="M12 5v14M5 12h14" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/></svg>
            Anuncie
          </a>

          {user ? (
              <div className="mt-2 flex flex-col">
              <span className="font-semibold mb-2">{displayName ?? user.email}</span>
              <button
                onClick={async () => {
                  try {
                    await signOut();
                    router.push("/");
                  } catch (e) {
                    console.error(e);
                  }
                }}
                className="bg-[#AF2828] text-white px-4 py-2 rounded-md"
              >
                Sair
              </button>
            </div>
          ) : (
            <Link href="/login" className="mt-2 bg-[#AF2828] text-white px-4 py-2 rounded-md flex items-center gap-2">
              <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/><circle cx="12" cy="7" r="4" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/></svg>
              Entrar
            </Link>
          )}
        </nav>
      )}

      {/* Antes havia um AuthModal aqui — agora a navegação vai para /login */}
    </header>
  );
}